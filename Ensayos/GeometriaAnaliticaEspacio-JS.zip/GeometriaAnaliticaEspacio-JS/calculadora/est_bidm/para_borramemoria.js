// JavaScript Document
function borramemoria() //De Enric
 {
	 document.estadistica.textarea.value="";
	 document.estadistica.textarea2.value="";
	 document.estadistica.textarea3.value="";
	 document.dibujame.ordenada.value="";
	 document.estadistica.frecuencia.value="";
	 document.estadistica.result1.value="";
	 document.estadistica.result2.value="";
	 document.estadistica.result3.value="";
	 document.estadistica.result4.value="";
	 document.estadistica.result5.value="";
	 document.estadistica.result6.value="";
	 document.estadistica.result7.value="";
	 document.estadistica.result8.value="";
	 document.estadistica.result9.value="";
	 document.estadistica.result10.value="";
	 document.estadistica.result11.value=""; 
	 
	 
	 	 
 }
