// JavaScript Document
function colocon(){
	alert("caramba");
}